<?php
return array(
    //    A
            "dongky",
            "admin",
            "administrator",
    //    B
    //    C
            'cskh',
            'cham_soc_khach_hang',
            'chutichnuoc',
            'chu_tich_nuoc',
    //    D
            'duongvantruong',
            'dm',
            'dcm',
            'ditconme',
    //    E
    //    F
            "fuck",
    //    G
            'god',
            'giamdoc',
    //    H
            "hochiminh",
    //    I
    //    J
    //    K
    //    L
    //    M
            'moderator',
            'mod',
    //    N
            "nguyentandung",
            'nguyen_tan_dung',
            'nguyenphutrong',
            'nguyen_phu_trong',
            'nguyensinhhung',
            'nguyen_sinh_hung',
    //    O            
    //    P
    //    Q
    //    R
    //    S
    //    T
            'tongbithu',
            'truong_tan_sang',
            'truongtansang',
            'tong_bi_thu',
    //    U
    //    V
    //    W
    //    X
    //    Y
    //    Z
);