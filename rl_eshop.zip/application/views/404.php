<div class="em-wrapper-main">
    <div class="container-fluid container-main">
        <div class="em-inner-main">
            <div class="em-wrapper-area02"></div>
            <div class="em-wrapper-area03"></div>
            <div class="em-wrapper-area04"></div>
            <div class="em-main-container em-col1-layout">
                <div class="row">
                    <div class="em-col-main col-sm-24">
                        <div class="std">
                            <div class="text-center">
                                <div class="not-pound-content">
                                    <p><img style="width: 70%" class="img-responsive" alt="" src="<?php echo base_url('public/assets/images/img-404.png')?>">
                                    </p>
                                    <div>
                                        <p>Rất tiếc, đã xảy ra lỗi...Trang quý khách truy cập không tìm được thấy.</p>
                                        <ul class="none-style">
                                            <li>Nếu quý khách nhập đường dẫn URL, vui lòng nhập chính xác.</li>
                                        </ul>
                                        <p>Tùy chọn</p>
                                        <ul class="none-style group-button">
                                            <li><a class="button-link" onclick="history.go(-1);" href="#"><span><span>Quay lại</span></span></a>
                                            </li>
                                            <li><a class="button-link" href="<?php echo base_url()?>"><span><span>Trang chủ</span></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>