<div class="row">
	<div class="span6">
		<div class="widget">
            <div class="widget-header"> <i class="icon-file"></i>
              <h3> Reviews</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
              	<ul class="messages_layout">
	                <li class="from_user left"> <a href="#" class="avatar"><img src="img/message_avatar1.png"></a>
	                  	<div class="message_wrap"> <span class="arrow"></span>
		                    <div class="info"> <a class="name">John Smith</a> <span class="time">1 hour ago</span>
		                      	<div class="options_arrow">
			                        <div class="dropdown pull-right"> <a class="dropdown-toggle " id="dLabel" role="button" data-toggle="dropdown" data-target="#" href="#"> <i class=" icon-caret-down"></i> </a>
			                          	<ul class="dropdown-menu " role="menu" aria-labelledby="dLabel">
				                            <li><a href="#"><i class=" icon-share-alt icon-large"></i> Reply</a></li>
				                            <li><a href="#"><i class=" icon-trash icon-large"></i> Delete</a></li>
			                          	</ul>
			                        </div>
		                      	</div>
		                    </div>
		                    <div class="text"> As an interesting side note, as a head without a body, I envy the dead. There's one way and only one way to determine if an animal is intelligent. Dissect its brain! Man, I'm sore all over. I feel like I just went ten rounds with mighty Thor. </div>
	                  	</div>
	                </li>
              	</ul>
            </div>
            <!-- /widget-content --> 
        </div>
	</div>
</div>