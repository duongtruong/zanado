    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title><?php echo $title?></title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">    
    
    <link href="<?php echo base_url()?>public/assets/administrator/css/bootstrap.min.css" rel="stylesheet">
    
    <link href="<?php echo base_url()?>public/assets/administrator/css/bootstrap-responsive.min.css" rel="stylesheet">
    
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
    
    <link href="<?php echo base_url()?>public/assets/administrator/css/font-awesome.css" rel="stylesheet">
    
    <link href="<?php echo base_url()?>public/assets/administrator/css/style.css" rel="stylesheet">
       
    <link href="<?php echo base_url()?>public/assets/administrator/css/pages/faq.css" rel="stylesheet"> 

    <link href="<?php echo base_url()?>public/assets/administrator/css/bootstrap-datetimepicker.min.css" rel="stylesheet"> 
    
    <link rel="stylesheet" href="<?php echo base_url()?>public/assets/administrator/js/jquery.plupload.queue/css/jquery.plupload.queue.css" type="text/css" media="screen" />
    
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>public/assets/administrator/css/bootstrap-select.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>public/assets/administrator/js/tree-multiselect/jquery.tree-multiselect.min.css">